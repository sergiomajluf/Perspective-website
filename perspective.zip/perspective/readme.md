Perspective
================================
Perspective is a study about seeing yourself from a different point of view, done through a Google Chrome extension which lets you know the amount of time you actively spend online as you browse through Facebook!

How do I install this?
-------------------------
* Clone/download this extension
* Open Chrome
* Hit the menu button on top right > Tools > Extensions
* Click on the "Developer mode" checkbox on the top if its not already checked
* Click on "Load unpacked extension"
* Select the FBTimer folder
* Start Facebook!

Who is this for?
-------------------------
For people who simply like to know how much time they spend on Facebook at a stretch.

Is it ready to be exported as a plugin?
-------------------------------
This was a one day project, it still requires a lot of polishing and additional features. Do let me know if you find any bugs!
